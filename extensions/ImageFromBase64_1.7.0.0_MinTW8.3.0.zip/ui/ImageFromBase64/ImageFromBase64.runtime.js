/*global Encoder,TW */

(function () {
    var addedDefaultButtonStyles = false;

    TW.Runtime.Widgets.ImageFromBase64 = function () {
        var thisWidget = this;

		this.runtimeProperties = function () {
		    return {
		        'needsDataLoadingAndError': false,
		        'propertyAttributes': {
		            'selector': {
		                'isLocalizable': false
		            }
		        }
		    };
		};

        this.renderHtml = function () {
            var html =
                '<div class="widget-content ImageFromBase64">'
                + '</div>';
            return html;
        };

        this.renderStyles = function () {};

        this.afterRender = function () {
        };

        this.beforeDestroy = function () {
            try {
                $("#tiptip_holder").remove();
                thisWidget.jqElement.unbind();
            } catch (err) {
                TW.log.error('Error in TW.Runtime.Widgets.ImageFromBase64.beforeDestroy', err);
            }
        };

        this.serviceInvoked = function (serviceName) {
            if (serviceName === 'RenderContent') {
            
            } else {
                TW.log.error('ImageFromBase64 widget, unexpected serviceName invoked "' + serviceName + '"');
            };
        };

		this.updateProperty = function (updatePropertyInfo) {
			if (updatePropertyInfo.TargetProperty === 'imageData') {
				var jqElementId = thisWidget.jqElementId;
				var imageData = updatePropertyInfo.SinglePropertyValue;
				thisWidget.setProperty("imageData",imageData);
				var objFit = thisWidget.getProperty("ImageScaling");
				var style = "object-fit:" + objFit;
				if(imageData != undefined && imageData != null && imageData != "") {
					var html = "<img style='width:100%;height:100%;"+style+"' src='data:image/png;base64,"+imageData+"'/>";
				}
	        	$("#"+jqElementId+" img").remove();
            	$("#"+jqElementId).append(html);
			}
		};
    };
}());