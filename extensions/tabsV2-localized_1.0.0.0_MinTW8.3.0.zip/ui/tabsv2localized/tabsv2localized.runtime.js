(function () {
	var addedDefaultStyles = false;	

	TW.Runtime.Widgets.tabsv2localized= function () {
		var thisWidget = this;
		var tabContainer;
		var overallJqElement, tabViewport, tabsRow, nextScrollBtn, backScrollBtn, tabSlider;
		var nTabs = 0;
		var tabHeight = thisWidget.getProperty('TabHeight',29);
		var curTabNumber = this.getProperty('DefaultTabAtRuntime',1);
		var curTab = 0, tabPageOffset = 0, tabSlideWidth, visibleTabs = [];
		var tabMaxWidth = parseInt(thisWidget.getProperty("MaxTabWidth"));
		var tabSpacing = thisWidget.getProperty('TabSpacing',2);
		var cornerRadius, roundedCorners;

		var buildLocalizablePropertyAttributes = function (widget) {
			nTabs = widget.getProperty('NumberOfTabs');
			var attributes = {'SelectedTabName':{'isLocalizable':true}};
			for (var tabNumber = 1; tabNumber <= nTabs; tabNumber++) {
				attributes['Tab' + tabNumber + 'Name'] = {'isLocalizable': true};
			}
			return attributes;
		};


		this.runtimeProperties = function () {
			return {
				'needsDataLoadingAndError': false,
				'isContainerWithDeclarativeSpotsForSubWidgets': true,
				'propertyAttributes': buildLocalizablePropertyAttributes(this)
			};
		};

		this.renderHtml = function () {
			var htmlTabs = '';
			var htmlTabContents = '';
			this.setProperty('CurrentTab', curTabNumber);


			roundedCorners = this.getProperty('RoundedCorners', true);

			nTabs = this.getProperty('NumberOfTabs');

			//MRD-536 tab disabled/enabled widget property should be settable without a binding
			var tabNumber, tagImageUrl, isVisible, isDisabled;
			for (tabNumber = 1; tabNumber <= nTabs; tabNumber++) {
				tagImageUrl = this.getProperty('Tab' + tabNumber + 'Image');
				isVisible = this.getProperty('Tab' + tabNumber + 'Visible', true);
				isDisabled = this.getProperty('Tab' + tabNumber + 'Disabled', true);
				var doImage = false;
				if (tagImageUrl !== undefined && tagImageUrl.length > 0) {
					doImage = true;
					tagImageUrl = TW.convertImageLink(tagImageUrl);
				}
				// Inserted Id value to div on line 62
				htmlTabs += 
					'<div class="tabsv2localized-tab ' + (tabNumber === curTabNumber ? 'selected' : '')  +
					(isDisabled ? ' disabled"' : ' enabled"') + '" tab-number="' + tabNumber + '" tab-value="' +
					this.getProperty('Tab' + tabNumber + 'Value') + '"' +
					(isVisible ? '' : ' style="display:none;"') + '>' +
					'<div style="max-width:'+tabMaxWidth+'px;" class="tab-content-table-wrapper">' +
					'<div id="'+this.properties.Id+'_Tab'+ tabNumber + 'Name" class="tab-text ' + '" tab-number="' + tabNumber + '" tab-value="' + this.getProperty('Tab' + tabNumber + 'Value') + '" title="' + XSS.encodeHTML(this.getProperty('Tab' + tabNumber + 'Name')) + '">' +
					(doImage ? '<img class="tab-image" src="' + tagImageUrl + '" />' : '') +
					Encoder.htmlEncode(this.getProperty('Tab' + tabNumber + 'Name')) +
					'</div>' +
					'</div>' +
					'</div>';

				// next and back tabs
				var tabNextImage =  ('<img class="tab-back-image" src="/Thingworx/MediaEntities/VerticalMenuArrow" />');
				var tabBackImage =  ('<img class="tab-next-image" style="-webkit-transform: rotate(180deg) translate(24px,0px); transform: rotate(180deg); translate(24px,0px);" src="/Thingworx/MediaEntities/VerticalMenuArrow" />');
				htmlTabContents +=
					'<div class="tabsv2localized-actual-tab-contents" tab-number="' + tabNumber + '" sub-widget-container-id="' + this.properties.Id + '"  sub-widget="' + tabNumber + '">' +
					'</div>';
			}

			var html = '';
			html +=
				'<div class="widget-tabsv2localized widget-container">' +
				'<div class="widget-content">' +
				'<div class="tab-content">' +
				'<div class="tabsv2localized-tab back-scroll-btnv2 disabled" >' +
				'<div class="tab-content-table-wrapper">' +
				'<div class="tab-text" title="'+TW.Runtime.convertLocalizableString('[[back]]')+'">'+tabBackImage+'</div>' +
				'</div>' +
				'</div>' +
				'<div class="tabsv2localized-tab next-scroll-btnv2 enabled" >' +
				'<div class="tab-content-table-wrapper">' +
				'<div class="tab-text" title="'+TW.Runtime.convertLocalizableString('[[next]]')+'">'+tabNextImage+'</div>' +
				'</div>' +
				'</div>' +
				'<div class="tabsv2localized-viewport">' +
				'<div class="tabsv2localized-slider">' +
				'<div class="tab-content-tabsv2localized">' +
				htmlTabs +
				'</div>' +
				'</div>' +
				'</div>' +
				'</div>' +
				'<div class="tab-container-background-wrapper" + style="top:'+ tabHeight + 'px;">' +
				htmlTabContents +
				'</div>' +

				'</div>' +
				'</div>' +
				'</div>';
			return html;
		};

		this.resize = function(){
			this.updateTabsRow();
		};

		this.afterRender = function () {
			overallJqElement = this.jqElement.closest('.widget-tabsv2localized');
			tabViewport = overallJqElement.find(".tabsv2localized-viewport");
			tabsRow = overallJqElement.find(".tab-content-tabsv2localized");
			nextScrollBtn = overallJqElement.find(".next-scroll-btnv2");
			backScrollBtn = overallJqElement.find(".back-scroll-btnv2");
			tabSlider = overallJqElement.find(".tabsv2localized-slider");

			tabContainer = overallJqElement.find('.tab-content').first();

			tabContainer.find('.tabsv2localized-tab').click(function (e) {
				var tabLi = $(e.target).closest('.tabsv2localized-tab');
				var tabNumber = parseInt(tabLi.attr('tab-number'));
				if(!tabLi.hasClass('disabled')){
					thisWidget.selectTab(tabNumber);
				}
			});

			nextScrollBtn.click(function (e) {
				if (curTab < nTabs-1 && nextScrollBtn.hasClass("enabled")) {
					var lastTab = tabsRow.children().eq(nTabs-1);
					// how far should tabsRow move for last page?
					if((lastTab.offset().left) <= (tabViewport.offset().left+tabSlideWidth)){
						nextScrollBtn.switchClass("enabled", "disabled");
					}
					curTab++;
					var thisTabPos = tabsRow.children().eq(visibleTabs[curTab-1]-1).offset().left;
					var nextTabPos = tabsRow.children().eq(visibleTabs[curTab]-1).offset().left;
					var nextTabOffset = nextTabPos - thisTabPos;
					tabPageOffset -= nextTabOffset;
					tabSlider.css({left: tabPageOffset});
					backScrollBtn.switchClass("disabled", "enabled");
					if (curTab === nTabs-1) {
						nextScrollBtn.switchClass("enabled", "disabled");
					}
				}
			});
			backScrollBtn.click(function (e) {
				if (curTab > 0) {
					// get the Left of the next tab to the Left
					var thisTabPos = tabsRow.children().eq(visibleTabs[curTab]-1).offset().left;
					var prevTabPos = tabsRow.children().eq(visibleTabs[curTab-1]-1).offset().left;
					var prevTabOffset = thisTabPos - prevTabPos;
					var prevTabName = tabsRow.children().eq(visibleTabs[curTab-1]-1).attr("tab-value");
					//use that value to move to next tab
					tabPageOffset += prevTabOffset;
					tabSlider.css({left: tabPageOffset});
					nextScrollBtn.switchClass("disabled", "enabled");
					curTab--;
					if (curTab === 0) {
						backScrollBtn.switchClass("enabled", "disabled");
					}
				}
			});
			var TabContentStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('TabContentStyle', 'DefaultTabContentStyle'));
			var TabUnselectedStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('TabUnselectedStyle', 'DefaultTabUnselectedStyle'));
			var TabSelectedStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('TabSelectedStyle', 'DefaultTabSelectedStyle'));
			var TabDisabledStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('TabDisabledStyle', 'DefaultTabDisabledStyle'));


			var TabContentBG = TW.getStyleCssGradientFromStyle(TabContentStyle);
			var TabBorder = TW.getStyleCssBorderFromStyle(TabContentStyle);
			var TabBorderSize = TabContentStyle.lineThickness;

			var TabDisabledContentBG = TW.getStyleCssGradientFromStyle(TabDisabledStyle);
			var TabDisabledBorder = TW.getStyleCssBorderFromStyle(TabDisabledStyle);
			var TabDisabledBorderSize = TabDisabledStyle.lineThickness;
			var TabDisabledText = TW.getStyleCssTextualNoBackgroundFromStyle(TabDisabledStyle);


			var TabUnselectedBG = TW.getStyleCssGradientFromStyle(TabUnselectedStyle);
			var TabUnselectedText = TW.getStyleCssTextualNoBackgroundFromStyle(TabUnselectedStyle);
			var TabUnselectedBorder = TW.getStyleCssBorderFromStyle(TabUnselectedStyle);
			var TabUnselectedBorderSize = TabUnselectedStyle.lineThickness;

			var TabSelectedBG = TW.getStyleCssGradientFromStyle(TabSelectedStyle);
			var TabSelectedText = TW.getStyleCssTextualNoBackgroundFromStyle(TabSelectedStyle);
			var TabSelectedBorder = TW.getStyleCssBorderFromStyle(TabSelectedStyle);
			var TabSelectedBorderSize = TabSelectedStyle.lineThickness;

			var TabUnselectedTextSize = TW.getTextSize(TabUnselectedStyle.textSize);
			var TabSelectedTextSize = TW.getTextSize(TabSelectedStyle.textSize);

			if (roundedCorners) {
				cornerRadius = 6
			} else {
				cornerRadius = 0
			}

			if (tabHeight === undefined) {
				tabHeight = 29;
			}

			if (thisWidget.getProperty('TabContentStyle', 'DefaultTabContentStyle') === 'DefaultTabContentStyle'
				&& thisWidget.getProperty('TabUnselectedStyle', 'DefaultTabUnselectedStyle') === 'DefaultTabUnselectedStyle'
					&& thisWidget.getProperty('TabSelectedStyle', 'DefaultTabSelectedStyle') === 'DefaultTabSelectedStyle') {
				if (!addedDefaultStyles) {
					addedDefaultStyles = true;
					var defaultStyles = ' .tab-container-background-wrapper { '+ TabContentBG + TabBorder + ' border-bottom-left-radius:'+ cornerRadius + 'px; border-bottom-right-radius:'+ cornerRadius + 'px; border-top-right-radius:'+ cornerRadius + 'px; overflow: hidden; }' +
					' .tabsv2localized-tab { ' + TabUnselectedBorder + ' border-width: ' + TabUnselectedBorderSize + 'px; border-top-left-radius:'+ cornerRadius + 'px; border-top-right-radius:'+ cornerRadius + 'px; overflow: hidden; } ' +
					' .tabsv2localized-tab .tab-content-table-wrapper { '+ TabUnselectedBG + ' }' +
					' .tab-text { '+ TabUnselectedText + TabUnselectedTextSize +' line-height:'+ (tabHeight - TabUnselectedBorderSize) + 'px; }' +
					' .tabsv2localized-tab.selected { ' + TabSelectedBorder + ' border-width: ' + TabSelectedBorderSize + 'px; }' +
					' .tabsv2localized-tab.selected .tab-content-table-wrapper { '+ TabSelectedBG + ' }' +
					' .tabsv2localized-tab.selected .tab-text { '+ TabSelectedText + ' line-height:'+ (tabHeight - TabSelectedBorderSize) + 'px; }' +
					' .tabsv2localized-tab { margin-right:'+ tabSpacing + 'px; }' +
					' .tabsv2localized-tab.disabled {'+ TabDisabledBorder + TabDisabledBorderSize +'}' +
					' .tabsv2localized-tab.disabled .tab-content-table-wrapper {'+ TabDisabledContentBG +'}' +
					' .tabsv2localized-tab.disabled .tab-content-table-wrapper .tab-text{'+ TabDisabledText +'}' +
					' .tabsv2localized-tab {max-width:'+tabMaxWidth+'%; }';
					$.rule(defaultStyles).appendTo(TW.Runtime.globalWidgetStyleEl);
				}
			} else {

				var styleBlock = 
					'<style>' +
					'#' + thisWidget.jqElementId + ' .tab-container-background-wrapper { '+ TabContentBG + TabBorder + ' border-bottom-left-radius:'+ cornerRadius + 'px; border-bottom-right-radius:'+ cornerRadius + 'px; border-top-right-radius:'+ cornerRadius + 'px; overflow: hidden; }' +
					'#' + thisWidget.jqElementId + ' .tabsv2localized-tab { ' + TabUnselectedBorder + ' border-width: ' + TabUnselectedBorderSize + 'px; border-top-left-radius:'+ cornerRadius + 'px; border-top-right-radius:'+ cornerRadius + 'px; overflow: hidden; } ' +
					'#' + thisWidget.jqElementId + ' .tabsv2localized-tab .tab-content-table-wrapper { '+ TabUnselectedBG + ' }' +
					'#' + thisWidget.jqElementId + ' .tab-text { '+ TabUnselectedText + TabUnselectedTextSize +' line-height:'+ (tabHeight - TabUnselectedBorderSize) + 'px; }' +
					'#' + thisWidget.jqElementId + ' .tabsv2localized-tab.selected { ' + TabSelectedBorder + ' border-width: ' + TabSelectedBorderSize + 'px; }' +
					'#' + thisWidget.jqElementId + ' .tabsv2localized-tab.selected .tab-content-table-wrapper { '+ TabSelectedBG + ' }' +
					'#' + thisWidget.jqElementId + ' .tabsv2localized-tab.selected .tab-text { '+ TabSelectedText + ' line-height:'+ (tabHeight - TabSelectedBorderSize) + 'px; }' +
					'#' + thisWidget.jqElementId + ' .tabsv2localized-tab { margin-right:'+ tabSpacing + 'px; }' +
					'#' + thisWidget.jqElementId + ' .tabsv2localized-tab.disabled {'+ TabDisabledBorder + TabDisabledBorderSize +'}' +
					'#' + thisWidget.jqElementId + ' .tabsv2localized-tab.disabled .tab-content-table-wrapper {'+ TabDisabledContentBG +'}' +
					'#' + thisWidget.jqElementId + ' .tabsv2localized-tab.disabled .tab-content-table-wrapper .tab-text{'+ TabDisabledText +'}' +
					'</style>';

				$(styleBlock).prependTo(thisWidget.jqElement);
			}
		};

		this.selectTab = function (tabNumber) {
			if(!isNaN(tabNumber)) {
				thisWidget.jqElement.children('.tab-container-background-wrapper').children('.tabsv2localized-actual-tab-contents[sub-widget-container-id="' + thisWidget.properties.Id + '"]').addClass('unselected-tabv2localized-container');
				thisWidget.jqElement.children('.tab-container-background-wrapper').children('.tabsv2localized-actual-tab-contents[sub-widget-container-id="' + thisWidget.properties.Id + '"][tab-number="' + tabNumber + '"]').removeClass('unselected-tabv2localized-container');

				_.each(thisWidget.jqElement.children('.tab-container-background-wrapper').children('.tabsv2localized-actual-tab-contents[sub-widget-container-id="' + thisWidget.properties.Id + '"]'),function(tab) {
					var tabEl = $(tab);
					var thisTabNum = tabEl.attr('tab-number');
					var showDataFilters = false;
					if( parseInt(thisTabNum) === tabNumber ) {
						showDataFilters = true;
					}
					_.each(tabEl.find('.widget-datafilter'),function(dataFilter) {
						var dataFilterEl = $(dataFilter);
						var jqElementId = dataFilterEl.attr('id');
						if( showDataFilters ) {
							$('div.twActiveFiltersBar[data-filter-id="' + jqElementId + '"]').show();
						} else {
							$('div.twActiveFiltersBar[data-filter-id="' + jqElementId + '"]').hide();
						}

					});
					_.each(tabEl.find('.BMCollectionViewMenuWrapper'),function(menu) {
						var menu = $(menu);
						showDataFilters ? menu.show() : menu.hide();
					});
				});

				tabContainer.find('.tabsv2localized-tab').removeClass('selected');
				tabContainer.find('.tabsv2localized-tab[tab-number="' + tabNumber.toString() + '"]').addClass('selected');

				this.setProperty('CurrentTab', tabNumber);
				this.setProperty('SelectedTabName', this.getProperty('Tab' + tabNumber.toString() + 'Name'));
				this.setProperty('SelectedTabValue', this.getProperty('Tab' + tabNumber.toString() + 'Value'));
				var widgetElement = this.jqElement;
				setTimeout(function () {
					widgetElement.triggerHandler('TabSelected');
				}, 1);

				var widgets = this.getWidgets();

				var currTab = widgets[tabNumber-1];
				// resize the tab we are selecting
				currTab.handleResponsiveWidgets();
				// trigger show event for each widget on the tab
				TW.CustomEventUtil.triggerOnWidget(currTab, 'twx-show');

//				// for now, just make sure we resize everything
//				this.handleResponsiveWidgets();
			}
			this.updateTabsRow();
		};

		this.serviceInvoked = function (serviceName) {
			if (serviceName === 'SelectDefaultTab') {
				if (curTabNumber === undefined) {
					curTabNumber = this.getProperty('CurrentTab');
				}
				if (curTabNumber === undefined) {
					curTabNumber = 1
				}
				this.selectTab(curTabNumber);
			} else {
				TW.log.error('Tabs widget, unexpected serviceName invoked "' + serviceName + '"');
			}
		};

		// this is called on your widget anytime bound data changes
		this.updateProperty = function (updatePropertyInfo) {
			switch (updatePropertyInfo.TargetProperty) {
			case 'SelectedTabValue':
			case 'SelectedTabName':
				if (updatePropertyInfo.RawSinglePropertyValue !== '') {
					var tabToSelect = undefined;
					var oldTabName = this.getProperty('SelectedTabName');
					if (updatePropertyInfo.TargetProperty === 'SelectedTabName') {
						var newTabName = updatePropertyInfo.RawSinglePropertyValue;
						this.setProperty('SelectedTabName', newTabName);
					}
					for (var tabNumber = 1; tabToSelect === undefined && tabNumber <= nTabs; tabNumber++) {
						if (updatePropertyInfo.TargetProperty === 'SelectedTabValue') {
							if (this.getProperty('Tab' + tabNumber.toString() + 'Value') === updatePropertyInfo.RawSinglePropertyValue) {
								tabToSelect = tabNumber;
							}
						} else if (updatePropertyInfo.TargetProperty === 'SelectedTabName') {
							if (this.getProperty('Tab' + tabNumber.toString() + 'Name') === this.getProperty('SelectedTabName')) {
								tabToSelect = tabNumber;
							}
						}
					}
					if (tabToSelect === undefined) {
						this.setProperty('SelectedTabName', oldTabName);
						TW.log.warn('Someone tried to select tab with "' + updatePropertyInfo.TargetProperty + '" of "' + updatePropertyInfo.RawSinglePropertyValue + '" which we did not match');
					} else {
						this.setProperty('SelectedTabValue', this.getProperty('Tab' + tabToSelect.toString() + 'Value'));
						this.selectTab(tabToSelect);
					}
				}
				break;
			default:
				/* Custom Code
				 * Author : MONTEV08
				 * Description : Capturing updation of property and updating corresponding value 
				 * */
				if (updatePropertyInfo.TargetProperty.indexOf('Name') !== -1) {
					this.setProperty(updatePropertyInfo.TargetProperty, updatePropertyInfo.RawSinglePropertyValue);
					tagImageUrl = this.getProperty(updatePropertyInfo.TargetProperty.replace("Name", "Image"));
					var doImage = false;
					if (tagImageUrl !== undefined && tagImageUrl.length > 0) {
						doImage = true;
						tagImageUrl = TW.convertImageLink(tagImageUrl);
					}
					// Updating Title value
					document.getElementById(this.properties.Id+"_"+updatePropertyInfo.TargetProperty).title = XSS.encodeHTML(this.getProperty(updatePropertyInfo.TargetProperty));
					// Updating the tab name and inserting the corresponding image if selected by user at design time
					document.getElementById(this.properties.Id+"_"+updatePropertyInfo.TargetProperty).innerHTML = (doImage ? '<img class="tab-image" src="' + tagImageUrl + '" />' : '') +
					Encoder.htmlEncode(this.getProperty(updatePropertyInfo.TargetProperty));
				}else{
					// End custom code
					var targetProperty = updatePropertyInfo.TargetProperty;
					var nIndexVisible = targetProperty.indexOf('Visible');
					var nIndexDisabled = targetProperty.indexOf('Disabled');

					if( nIndexVisible > 0 ) {
						var isVisible = updatePropertyInfo.RawSinglePropertyValue;
						if( isVisible !== false ) {
							isVisible = true;
						}
						this.setProperty(targetProperty,isVisible);
						var tabNumber = parseInt(targetProperty.substring(3,nIndexVisible));
						var tabEl = tabContainer.find('.tabsv2localized-tab[tab-number="' + tabNumber.toString() + '"]');
						if( isVisible ) {
							tabEl.show();
						} else {
							if( tabEl.hasClass('selected') ) {
								for (var newTabNumber = 1; newTabNumber<=nTabs; newTabNumber++) {
									if (this.getProperty('Tab' + newTabNumber.toString() + 'Visible') === true )  {
										this.selectTab(newTabNumber);
										break;
									}
								}
							}
							tabEl.hide();
						}
						this.updateTabsRow();
					}
					var isDisabled = updatePropertyInfo.RawSinglePropertyValue;
					var disabledTabNumber = parseInt(targetProperty.substring(3,nIndexDisabled));
					var disabledTabEl = tabContainer.find('.tabsv2localized-tab[tab-number="' + disabledTabNumber.toString() + '"]');
					if (nIndexDisabled > 0) {
						if(isDisabled !== false) {
							isDisabled = true;
						}
						if(isDisabled){
							disabledTabEl.removeClass('enabled');
							disabledTabEl.addClass('disabled');
						} else {
							disabledTabEl.removeClass('disabled');
							disabledTabEl.addClass('enabled');
						}

					}
				}
			break;
			}
		};

		this.updateTabsRow = function() {
			//get widths required to determine if paging is needed
			var thisWidgetCurrentWidth = overallJqElement.width();
			var tabsWidth = 0;
			//set common parameters
			tabSlider.css({"top":0,"height":tabHeight});
			tabViewport.css({"top":0,"height":tabHeight});
			tabsRow.css({"top":0,"left":0,"height":tabHeight});
			visibleTabs = [];
			var myTabs = 0;
			// calculate width required to display row of tabs in one line
			thisWidget.jqElement.find('.tab-content-tabsv2localized .tabsv2localized-tab').each(function(index) {
				if($(this).is(":visible")&& myTabs < nTabs) {
					tabsWidth += $(this).width() + tabSpacing;
					visibleTabs.push($(this).attr("tab-number"));
				}
				myTabs++;
			});
			tabsRow.width(tabsWidth+20);
			// show tab paging
			if(tabsWidth>overallJqElement.width()) {
				//$(".tab-container-background-wrapper").css("border-top-right-radius",0);
				var scrollBtnWidth = nextScrollBtn.outerWidth()+tabSpacing;
				tabSlideWidth = thisWidgetCurrentWidth-((scrollBtnWidth)*2)-(cornerRadius+3+tabSpacing);
				tabSlider.css({"width":tabSlideWidth});
				nextScrollBtn.css({
					"left":(thisWidgetCurrentWidth-(2+cornerRadius))-(scrollBtnWidth*2),
					"top":0
				});
				nextScrollBtn.switchClass("disabled","enabled");
				tabViewport.css({
					"margin-left":scrollBtnWidth,
					"width":tabSlideWidth
				});
				nextScrollBtn.show();
				backScrollBtn.show();
			}else{
				//$(".tab-container-background-wrapper").css("border-top-right-radius",cornerRadius);
				nextScrollBtn.hide();
				backScrollBtn.hide();
				tabsRow.css({"width":overallJqElement.width()+tabMaxWidth,"margin-left":0,"left":0});
				tabSlider.css({"width":overallJqElement.width()-1,"margin-left":0,"left":0});
				tabViewport.css({"width":overallJqElement.width()-1,"margin-left":0});
			}
		};

		this.afterWidgetsRendered = function () {
			thisWidget.selectTab(thisWidget.getProperty('CurrentTab'));
		};
	};

}());