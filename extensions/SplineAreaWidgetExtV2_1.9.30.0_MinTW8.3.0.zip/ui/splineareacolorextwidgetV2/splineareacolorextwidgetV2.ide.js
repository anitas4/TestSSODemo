TW.IDE.Widgets.splineareacolorextwidgetV2 = function () {

	this.widgetIconUrl = function() {
		return  "'../Common/extensions/SplineAreaWidgetExtV2/ui/splineareacolorextwidgetV2/default_widget_icon.ide.png'";
	};

	this.widgetProperties = function () {
		return {
			'name': 'SplineAreaColorExtWidgetV2',
			'description': '',
			'supportsAutoResize': true,
			'category': ['Common'],
			'properties': {
				'SplineAreaColorExtWidgetV2 Property': {
					'baseType': 'STRING',
					'defaultValue': 'SplineAreaColorExtWidgetV2 Property default value',
					'isBindingTarget': true
				},
				'data': {
					'baseType' : 'JSON',
					'defaultValue' : {},
					'isBindingTarget': true
				},
				'DBJson': {
					'baseType' : 'JSON',
					'defaultValue' : {},
					'isBindingTarget': true
				}
			}
		}
	};

	this.afterSetProperty = function (name, value) {
		var thisWidget = this;
		var refreshHtml = false;
		switch (name) {
			case 'Style':
			case 'SplineAreaColorExtWidgetV2 Property':
				thisWidget.jqElement.find('.splineareacolorextwidgetV2-property').text(value);
			case 'Alignment':
				refreshHtml = true;
				break;
			default:
				break;
		}
		return refreshHtml;
	};

	this.renderHtml = function () {
		// return any HTML you want rendered for your widget
		// If you want it to change depending on properties that the user
		// has set, you can use this.getProperty(propertyName).
		return 	'<div class="widget-content widget-splineareacolorextwidgetV2">' +
					'<span class="splineareacolorextwidgetV2-property">' + this.getProperty('SplineAreaColorExtWidgetV2 Property') + '</span>' +
				'</div>';
	};

	this.afterRender = function () {
		// NOTE: this.jqElement is the jquery reference to your html dom element
		// 		 that was returned in renderHtml()

		// get a reference to the value element
		valueElem = this.jqElement.find('.splineareacolorextwidgetV2-property');
		// update that DOM element based on the property value that the user set
		// in the mashup builder
		valueElem.text(this.getProperty('SplineAreaColorExtWidgetV2 Property'));
	};

};