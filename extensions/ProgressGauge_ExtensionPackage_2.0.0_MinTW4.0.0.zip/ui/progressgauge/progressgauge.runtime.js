﻿TW.Runtime.Widgets.progressgauge = function () {
	
	var gaugeElementId;
	var borderWidth = 0;
	
    this.runtimeProperties = function () {
        return {
            'needsError': true
        };
    };

    this.renderHtml = function () {
    	this.haveData = false;
    	
        var html = '<div class="widget-content widget-progressgauge"></div>';
        return html;
    };

    this.beforeDestroy = function () {
    	this.cleanupGauge();
    	
        if(this.paper !== undefined) {
            try {
            	this.paper.clear();
            	this.paper.remove();
            	
    			try {
    				TW.purgeJqElement(this,false);
    			}
    			catch(err) {
    				TW.log.error('purge error: ' + err);
    			}

            	this.paper = null;
            	delete this.paper;
            }
            catch (destroyErr) {
            }
        }

    };


    this.afterRender = function () {

		var domElementId = this.jqElementId;
		var widgetElement = this.jqElement;
		gaugeElementId = domElementId + '-widget-progressgauge-container';
		widgetElement.append('<div id="'+ gaugeElementId +'"></div>');

		var formatResult = TW.getStyleFromStyleDefinition(this.getProperty('GaugeStyle'));
		var cssGaugeBorder = TW.getStyleCssBorderFromStyle(formatResult);

		var styleBlock = 
			'<style>' +
				'#' + gaugeElementId + ' {'+ cssGaugeBorder +'}' +				
			'</style>';

		$(styleBlock).prependTo(widgetElement);

		if(formatResult.lineThickness !== undefined && formatResult.lineThickness !== '') {
			borderWidth = parseInt(formatResult.lineThickness);
		} else {
			borderWidth = 0;
		}

	
    	this.drawGauge();
    };

    this.cleanupGauge = function() {
    	if(this.chartBackgroundRectangle !== undefined && this.chartBackgroundRectangle !== null) {
    		this.chartBackgroundRectangle.remove();
    		this.chartBackgroundRectangle = null;
    		delete this.chartBackgroundRectangle;
    	}

    	if(this.gaugeCircle !== undefined && this.gaugeCircle !== null) {
    		this.gaugeCircle.remove();
    		this.gaugeCircle = null;
    		delete this.gaugeCircle;
    	}

    	if(this.gaugeFaceCircle !== undefined && this.gaugeFaceCircle !== null) {
    		this.gaugeFaceCircle.remove();
    		this.gaugeFaceCircle = null;
    		delete this.gaugeFaceCircle;
    	}

    	if(this.valueText !== undefined && this.valueText !== null) {
    		this.valueText.remove();
    		this.valueText = null;
    		delete this.valueText;
    	}

    	if(this.valueTextBackground !== undefined && this.valueTextBackground !== null) {
    		this.valueTextBackground.remove();
    		this.valueTextBackground = null;
    		delete this.valueTextBackground;
    	}

    	this.cleanupMask();
    };
    
    this.cleanupMask = function() {
    	if(this.maskElement !== undefined && this.maskElement !== null) {
    		this.maskElement.remove();
    		this.maskElement = null;
    		delete this.maskElement;
    	}
    	
    };
    
    this.updateGauge = function(value,data) {
    	this.cleanupMask();
    	
    	if(value == undefined) {
    		if(this.valueText !== undefined)
    			this.valueText.hide();

    		return;
    	}
    	
		if(this.valueText !== undefined) {
			this.valueText.hide();
	    	
			var formattedValue = value.format(this.valueformatString);
			
			this.valueText.attr('text',formattedValue);
	        this.valueText.show();
    	}
    
    	var widgetProperties = this.properties;
    	
    	var hasTextFormatting = widgetProperties['ValueFormatter'] !== undefined;

        if (hasTextFormatting) {
        	var valueStyle;
        	
        	if(widgetProperties['ValueFormatter'] !== undefined)  {
        		valueStyle = TW.getStyleFromStateFormatting({ DataRow: data, StateFormatting: widgetProperties['ValueFormatter'] });
        		
	            if (valueStyle.styleDefinitionName !== undefined) {
	            	
	        		if(this.valueText !== undefined) {
	        			this.valueText.attr('fill',valueStyle.foregroundColor);
	        		}
	            }
        	}
        	
        }

        var minRange = widgetProperties["MinValue"];
        if(minRange == undefined)
        	minRange = 0;
        
        var maxRange = widgetProperties["MaxValue"];
        if(maxRange == undefined)
        	maxRange = 100;

        var aperture = widgetProperties['Aperture'];
        if(aperture == undefined)
        	aperture = 270;
        
        var referenceAngle = widgetProperties['ReferenceAngle'];
        if(referenceAngle == undefined)
        	referenceAngle = 225;
        
        var rotationAngle = referenceAngle + aperture * (value - minRange) / (maxRange - minRange);

        if(value != undefined) {
        	// Draw ring
            
            if(this.ringWidth > 0) {
                var r2 = (this.faceDiameter / 2.0);
                var r1 = r2 - this.ringWidth;

                var previousValue = minRange;
                
                // Don't draw zero degree wedges
                
                if(value !== previousValue) {
                    var endAngle = -referenceAngle - aperture * (minRange- minRange) / (maxRange - minRange) + 90;
                    var startAngle = -referenceAngle - aperture * (value - minRange) / (maxRange - minRange) + 90;

                    var progressBackground = "#ffffff";
                    
                    var progressStyleDefinition = TW.getStyleFromStyleDefinition(widgetProperties['ProgressStyle']);

                    if (progressStyleDefinition !== undefined && progressStyleDefinition.styleDefinitionName !== undefined) {
                        progressBackground = progressStyleDefinition.backgroundColor;
                    }

                	var hasProgressFormatting = widgetProperties['ProgressFormatter'] !== undefined;

                    if (hasProgressFormatting) {
                    	if(widgetProperties['ProgressFormatter'] !== undefined)  {
                    		var progressStyle = TW.getStyleFromStateFormatting({ DataRow: data, StateFormatting: widgetProperties['ProgressFormatter'] });
                    		
                            if (progressStyle.styleDefinitionName !== undefined) {
                                progressBackground = progressStyle.backgroundColor;
                            }
                    	}
                    	
                    }

                    if(value <= maxRange) {
                    	this.maskElement = TW.ChartLibrary.drawSector(this.paper, this.centerX, this.centerY, r1, r2, startAngle, endAngle);
                        this.setShapeStyle(this.maskElement, progressBackground, progressBackground, 'none', 'none', undefined, 1);
                    }
                    else {
                    	var middleRadius = (r1 + r2) / 2;
                    	this.maskElement = TW.ChartLibrary.drawCircle(this.paper, this.centerX, this.centerY, middleRadius, middleRadius, this.ringWidth, progressBackground); 
                    }
    	        }
            }
        };
        
        this.previousRotationAngle = rotationAngle;
    };
    
    this.setShapeStyle = function(element,fill,secondaryFill,fillType,fillOrientation,stroke,strokeWidth) {
		TW.ChartLibrary.setElementStyle(element, fill, secondaryFill, fillType, fillOrientation, stroke, strokeWidth, TW.ChartLibrary.STROKE_SOLID);
    };

    this.drawGauge = function() {

        var widgetProperties = this.properties;

        var width = widgetProperties['Width'] - (borderWidth * 2);
        var height = widgetProperties['Height'] - (borderWidth * 2);
        
        if(widgetProperties['GaugeStyle'] === undefined) {
        	widgetProperties['GaugeStyle'] = 'DefaultProgressGaugeStyle';
        }
        
        if(widgetProperties['GaugeFaceStyle'] === undefined) {
        	widgetProperties['GaugeFaceStyle'] = 'DefaultProgressGaugeFaceStyle';
        }
        
        if(widgetProperties['ValueStyle'] === undefined) {
        	widgetProperties['ValueStyle'] = 'DefaultProgressGaugeIndicatorStyle';
        }
        
        if(widgetProperties['ProgressStyle'] === undefined) {
        	widgetProperties['ProgressStyle'] = 'DefaultProgressGaugeIndicatorStyle';
        }
        
        var chartStyleDefinition = TW.getStyleFromStyleDefinition(widgetProperties['GaugeStyle']);

        var chartBackground = "#ffffff";
        var chartSecondaryBackground = undefined;
        var chartBorder = undefined;
        var chartBorderWidth = 0;
        
        if (chartStyleDefinition !== undefined) {
            chartBackground = chartStyleDefinition.backgroundColor;

            if (chartStyleDefinition.secondaryBackgroundColor !== undefined && chartStyleDefinition.secondaryBackgroundColor != chartStyleDefinition.backgroundColor && chartStyleDefinition.secondaryBackgroundColor !== '')
                chartSecondaryBackground = chartStyleDefinition.secondaryBackgroundColor;
        }

        var gaugeFaceBackground = "#ffffff";
        var gaugeFaceSecondaryBackground = undefined;
        var gaugeFaceBorder = "#000000";
        var gaugeFaceBorderWidth = 1;
        
        var gaugeFaceStyleDefinition = TW.getStyleFromStyleDefinition(widgetProperties['GaugeFaceStyle']);

        if (gaugeFaceStyleDefinition !== undefined && gaugeFaceStyleDefinition.styleDefinitionName !== undefined) {
            gaugeFaceBackground = gaugeFaceStyleDefinition.backgroundColor;

            if (gaugeFaceStyleDefinition.secondaryBackgroundColor !== undefined && gaugeFaceStyleDefinition.secondaryBackgroundColor != gaugeFaceStyleDefinition.backgroundColor && gaugeFaceStyleDefinition.secondaryBackgroundColor !== '')
                gaugeFaceSecondaryBackground = gaugeFaceStyleDefinition.secondaryBackgroundColor;

            gaugeFaceBorder = gaugeFaceStyleDefinition.lineColor;
            gaugeFaceBorderWidth = parseInt(gaugeFaceStyleDefinition.lineThickness);
        }

    	var absolutePadding = 6;

        var gaugeBorderSize = widgetProperties['GaugeBorder'];

        if(gaugeBorderSize == undefined)
        	gaugeBorderSize = 16;
        
        var effectiveHeight = height - 2 * absolutePadding;
        var effectiveWidth = width - 2 * absolutePadding;
        
        var gaugeDiameter = effectiveWidth;

        if (effectiveHeight < effectiveWidth)
            gaugeDiameter = effectiveHeight;

        this.ringWidth = widgetProperties['RingWidth'];

        if(this.ringWidth == undefined)
        	this.ringWidth = 16;
        
        this.faceDiameter = gaugeDiameter - gaugeBorderSize;

    	var paperWidth = width;
    	var paperHeight = height;
    	
		var centerX = width/2;
		var centerY = height/2;

		this.centerX = centerX;
		this.centerY = centerY;
		
		if(this.paper === undefined) {
			this.paper = Raphael(gaugeElementId, paperWidth, paperHeight);
		}
		else {
			this.cleanupGauge();
		}
		
		this.chartBackgroundRectangle = this.paper.rect(0, 0, width, height);
		this.setShapeStyle(this.chartBackgroundRectangle, chartBackground, chartSecondaryBackground, TW.ChartLibrary.FILL_LINEAR, TW.ChartLibrary.ORIENTATION_VERTICAL, chartBorder, chartBorderWidth);
		
		this.gaugeFaceCircle = this.paper.circle(centerX, centerY, (gaugeDiameter / 2.0));
		this.setShapeStyle(this.gaugeFaceCircle, gaugeFaceBackground, gaugeFaceSecondaryBackground, TW.ChartLibrary.FILL_LINEAR, TW.ChartLibrary.ORIENTATION_VERTICAL, gaugeFaceBorder, gaugeFaceBorderWidth);
		
        var minRange = this.getProperty("MinValue");
        if(minRange == undefined)
        	minRange = 0;
        
        var maxRange = this.getProperty("MaxValue");
        if(maxRange == undefined)
        	maxRange = 100;

        var aperture = widgetProperties['Aperture'];
        if(aperture == undefined)
        	aperture = 360;
        
        var referenceAngle = widgetProperties['ReferenceAngle'];
        if(referenceAngle == undefined)
        	referenceAngle = 0;
        
        var valuedecimals = widgetProperties['ValueDecimals'];

        if (valuedecimals == undefined) {
            valuedecimals = widgetProperties['Decimals'];

            if (valuedecimals == undefined)
            	valuedecimals = 0;
        }

        var valuedigits = widgetProperties['ValueDigits'];

        if (valuedigits == undefined)
        	valuedigits = 3;

        var valueformatString = "0";
        
        if(valuedecimals > 0)
        	valueformatString = valueformatString + ".";
        
        for(var i=0;i<valuedecimals;i++) {
       		valueformatString = valueformatString + "0";
        }

        this.valueformatString = valueformatString;
        
        var valueFontColor = "#000080";
        var valueFontBold = false;
        var valueFontSizeName = "normal";
        
        var valueStyleDefinition = TW.getStyleFromStyleDefinition(widgetProperties['ValueStyle']);


        if (valueStyleDefinition !== undefined && valueStyleDefinition.styleDefinitionName !== undefined) {
            valueFontColor = valueStyleDefinition.foregroundColor;
            valueFontBold = valueStyleDefinition.fontEmphasisBold;
            valueFontSizeName = valueStyleDefinition.textSize;
        }

    	var valueFontSize = TW.ChartLibrary.getFontSize(valueFontSizeName);
    	
        var xpos = centerX;
        var ypos = centerY;
            
        var value = 0.0;
        var valueText = value.format(valueformatString);
        
        this.valueText = this.paper.text(xpos,ypos,valueText).attr({ "font-size": valueFontSize, "font-family": "Segoe UI, Arial, Sans Serif", "fill" : valueFontColor, "font-weight" : valueFontBold ? "bold" : "normal"  });
        this.valueText.hide();
    };
    
    this.updateProperty = function (updatePropertyInfo) {
        if (updatePropertyInfo.TargetProperty === "ValueFormatter") {
        	this.drawGauge();
        	
        	if(this.lastValue !== undefined) {
        		this.updateGauge(this.lastValue,this.lastDataRow);
        	}
        }
        
        if (updatePropertyInfo.TargetProperty === "MinValue" || updatePropertyInfo.TargetProperty === "MaxValue" || updatePropertyInfo.TargetProperty === "ReferenceAngle" || updatePropertyInfo.TargetProperty === "Aperture") {
        	this.setProperty(updatePropertyInfo.TargetProperty,updatePropertyInfo.RawSinglePropertyValue);
        	this.drawGauge();
        	
        	if(this.lastValue !== undefined) {
        		this.updateGauge(this.lastValue,this.lastDataRow);
        	}
        	
            return;
        }

        if (updatePropertyInfo.TargetProperty === "Data") {
        	var value = updatePropertyInfo.RawSinglePropertyValue;
        	var datarow = updatePropertyInfo.ActualDataRows[0];
        	
        	this.lastValue = value;
        	this.lastDataRow = datarow;
        	
        	this.updateGauge(value,datarow);
        }
    };

};

