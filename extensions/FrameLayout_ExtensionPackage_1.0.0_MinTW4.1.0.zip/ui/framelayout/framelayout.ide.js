TW.IDE.Widgets.framelayout = function () {

	this.widgetIconUrl = function() {
    	return  "../Common/extensions/FrameLayout_ExtensionPackage/ui/framelayout/framelayout.ide.png";
	}
	
	var thisWidget = this;
    this.widgetProperties = function () {
        return {
            'name': 'Frame Layout',
            'description': 'Provides two responsive containers that are stacked one on top of the other.',
			'icon': 'framelayout.ide.png',
            'category': ['Common', 'Containers'],
            'isContainer': true,
            'isDraggable': true,
	        'supportsAutoResize': true,
	        'onlySupportedInResponsiveParents': true,
            'isContainerWithDeclarativeSpotsForSubWidgets': true,
            'allowPasteOrDrop': false,
            'isDraggable': false,
            'allowPositioning': false,
            'properties': {
                'ResponsiveLayout': {
                    'baseType': 'BOOLEAN',
                    'defaultValue': true,
                    isVisible: false
                },
				'BackgroundFrameVisible': {
					'description': 'If enabled, this will hide the background frame at design time, to make it easy to modify the foreground frame.',
					'baseType': 'BOOLEAN',
					'defaultValue': true
				},
				'ForegroundFrameVisible': {
					'description': 'If enabled, this will hide the foreground frame at design time, to make it easy to modify the background frame.',
					'baseType': 'BOOLEAN',
					'defaultValue': true
				},
                'Style': {
                    'baseType': 'STYLEDEFINITION',
					'defaultValue': 'DefaultPanelStyle'
                }
            }
        };
    };

    this.beforeSetProperty = function (name, value) {
    };
	
	this.setFrameVisibilities = function() {
		
			if (this.getProperty("ForegroundFrameVisible")) {
				var selector = this.jqElement.find('.frame-content[sub-widget-container-id="' + this.properties.Id + '"][sub-widget="1"]').show();
			}
			else {
				var selector = this.jqElement.find('.frame-content[sub-widget-container-id="' + this.properties.Id + '"][sub-widget="1"]').hide();
			}
			
			if (this.getProperty("BackgroundFrameVisible")) {
				var selector = this.jqElement.find('.frame-content[sub-widget-container-id="' + this.properties.Id + '"][sub-widget="2"]').show();
			}
			else {
				var selector = this.jqElement.find('.frame-content[sub-widget-container-id="' + this.properties.Id + '"][sub-widget="2"]').hide();
			}
			
	}

    this.afterSetProperty = function (name, value) {
		
		if (name == "ForegroundFrameVisible") {
			if (value) {
				var selector = this.jqElement.find('.frame-content[sub-widget-container-id="' + this.properties.Id + '"][sub-widget="1"]').show();
			}
			else {
				var selector = this.jqElement.find('.frame-content[sub-widget-container-id="' + this.properties.Id + '"][sub-widget="1"]').hide();
			}
		}
		else if (name == "BackgroundFrameVisible") {
			if (value) {
				var selector = this.jqElement.find('.frame-content[sub-widget-container-id="' + this.properties.Id + '"][sub-widget="2"]').show();
			}
			else {
				var selector = this.jqElement.find('.frame-content[sub-widget-container-id="' + this.properties.Id + '"][sub-widget="2"]').hide();
			}
		}

        var thisWidget = this;
        var result = false;
        switch (name) {
            case 'Style':
            case 'Top':
            case 'Left':
            case 'Right':
            case 'Bottom':
            case 'Width':
            case 'Height':
            case 'HorizontalAnchor':
            case 'VerticalAnchor':
			case 'LeftMargin':
			case 'RightMargin':
			case 'TopMargin':
			case 'BottomMargin':
			case 'WidthUnit':
			case 'HeightUnit':
                result = true;
                break;
            default:
                break;
        }
        return result;

    };

	this.afterCreate = function() {
		this.showProperProperties();
	};

	this.afterLoad = function() {
		this.showProperProperties();
	};

	this.showProperProperties = function() {
		var thisWidget = this;

		var allWidgetProps = thisWidget.allWidgetProperties();

		/*if( thisWidget.properties.ResponsiveLayout === true ) {
			allWidgetProps.properties['HorizontalAnchor']['isVisible'] = false;
			allWidgetProps.properties['VerticalAnchor']['isVisible'] = false;
		} else {
			allWidgetProps.properties['HorizontalAnchor']['isVisible'] = true;
			allWidgetProps.properties['VerticalAnchor']['isVisible'] = true;
		}*/
	};	
	
	
	this.afterCreate = function() {
		var thisWidget = this;

		for (var i = 0; i < 2; i++) {
			var widgetObj = this;
			var widgetToAdd = TW.IDE.Widget.factory({ 'Type': 'container' });
			var newId = TW.IDE.Workspace.Mashups.NewID('frame');
			widgetToAdd.setProperty('Id', newId);
			widgetToAdd.setInternalProperty('DisplayName', 'Frame');
			widgetToAdd.setInternalProperty('ResponsiveLayout', true);
			widgetObj.addWidget(widgetToAdd, true /*new*/);
		}
		
	};

    this.renderHtml = function () {
		var formatResult = TW.getStyleFromStyleDefinition(this.getProperty('Style'));
		var cssPanelBackground = TW.getStyleCssGradientFromStyle(formatResult);
		var cssPanelBorder = TW.getStyleCssBorderFromStyle(formatResult);
		
        var html = '';

        html +=
        '<div class="widget-content widget-panel widget-container" style="' + ((formatResult.image !== undefined && formatResult.image.length > 0) ? 'background-color: ' + formatResult.backgroundColor + '; background-image: url(' + formatResult.image + '); background-image: url(' + formatResult.image + '), -moz-linear-gradient(top,  ' + formatResult.backgroundColor + ',  ' + formatResult.secondaryBackgroundColor + '); background-image: url(' + formatResult.image + '), -webkit-gradient(linear, left top, left bottom, from(' + formatResult.backgroundColor + '), to(' + formatResult.secondaryBackgroundColor + ')); background-image: url(' + formatResult.image + '), -webkit-linear-gradient(top, ' + formatResult.backgroundColor + ', ' + formatResult.secondaryBackgroundColor + '); background-repeat: no-repeat; background-position: center center;' : '') + ' background-image: url(' + formatResult.image + '), -ms-linear-gradient(top, ' + formatResult.backgroundColor + ', ' + formatResult.secondaryBackgroundColor + ');">' +
			'<div class="frame-content" style="width: 100%; height: 100%; position: absolute;" sub-widget-container-id="' + this.properties.Id + '"  sub-widget="1"></div>' +
			'<div class="frame-content" style="width: 100%; height: 100%; position: absolute;" sub-widget-container-id="' + this.properties.Id + '"  sub-widget="2"></div>' +
        '</div>';
        return html;
    };

	this.afterRender = function() {
		
		var PanelStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('Style'));
		var PanelBG = TW.getStyleCssGradientFromStyle(PanelStyle);
		var PanelBorder = TW.getStyleCssBorderFromStyle(PanelStyle);
		
		var resource = TW.IDE.getMashupResource();
        var widgetStyles =
            '#' + thisWidget.jqElementId + '.widget-panel { '+ PanelBG + PanelBorder +' } ' ;
        resource.styles.append(widgetStyles);

	    if( thisWidget.getProperty('IsPrintLayout') ) {
		    thisWidget.jqElement.addClass('is-print-mashup');
	    }
		
		this.setFrameVisibilities();

	};

};