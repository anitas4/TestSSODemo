/*global TW */  // For JSHint'ing

TW.Runtime.Widgets.paging = function () {
    "use strict";
    var thisWidget = this;
    var addedDefaultStyles = false;
    var currentPagesSet = false,
        totalItemsSet = false;
    var pageControlsElement;
    var itemsLabelElement;
    var currentPage = thisWidget.getProperty("CurrentPage");
    var pageSize = thisWidget.getProperty("PageSize");
    var totalItems = thisWidget.getProperty("TotalItems");
    var rangeExtent = 5;

    this.runtimeProperties = function () {
        return {
            'propertyAttributes': {
                'ItemsLabel': {
                    'isLocalizable': true
                }
            }
        };
    };

    this.renderHtml = function () {
        var pageControlsHtml = getPageControlsHtml();
        var html = "<div class=\"widget-content widget-paging\">" +
            "<span class='items-label'>" + this.getProperty("ItemsLabel") + "</span>" +
                "<span class='page-controls'>" +
                    pageControlsHtml +
                "</span>" +
            "</div>";
        return html;
    };

    /**
     * Always show 5 pages (rangeExtent), including the currentPage.
     *
     * At the beginning of the page list, show the first 5.
     * At the middle, show 1 before and 4 after current page, with ellipsis (...) to indicate pages not shown.
     * At the end, show the last 5.
     * Always show the first and last page.
     * Show previous and next links, when appropriate.
     *
     * @returns {string}
     */
    var getPageControlsHtml = function() {
        var html = '';
        var totalPages = Math.ceil(totalItems / pageSize)

        if (totalPages > 1) {
            var prevPage = currentPage - 1;
            var nextPage = currentPage + 1;

            var rangeStart = 0;
            var rangeEnd = totalPages;
            if (totalPages > rangeExtent) {
                rangeStart = Math.max(currentPage - 1, 0);
                // Adjust at end
                if (currentPage > totalPages - rangeExtent) {
                    rangeStart = totalPages - rangeExtent;
                }
                rangeEnd = Math.min(rangeStart + rangeExtent, totalPages);
            }

            for (var p = 0; p < totalPages; p++) {
                var pageDisplay = p + 1;

                if (p === 0) {
                    html += '&nbsp;|&nbsp;';
                    if (currentPage > 0) {
                        var previousLabel = TW.Runtime.convertLocalizableString("[[PTC.SCA.SCO.PagingWidget.Previous]]");
                        html +=  "<a class='previous-page pagingcontroller' data-page-number='" + prevPage + "'>&nbsp;" + previousLabel + "</a>";
                    }
                }

                switch(p) {
                    case currentPage:
                        html += "<span class='current-page'>" + pageDisplay + "</span>";
                        break;
                    case 0:
                    case totalPages - 1:
                        html += "<a class='pagingcontroller'  data-page-number='" + p + "'>" + pageDisplay + "</a>";
                        break;
                    case rangeStart - 1:
                        html += "<span class='previous-ellipsis'>&hellip;</span>";
                        break;
                    case rangeEnd:
                        html += "<span class='next-ellipsis'>&hellip;</span>";
                        break;
                    default:
                        if (p >= rangeStart && p < rangeEnd) {
                            html += "<a class='pagingcontroller'  data-page-number='" + p + "'>" + pageDisplay + "</a>";
                        }
                        break;
                }

                if (p === totalPages - 1 && currentPage < totalPages - 1) {
                    var nextLabel = TW.Runtime.convertLocalizableString("[[PTC.SCA.SCO.PagingWidget.Next]]");
                    html += "<a class='next-page pagingcontroller'  data-page-number='" + nextPage + "'>" + nextLabel + "&nbsp;</a>";
                }

            }
        }

        return html;
    };

    this.executePagingAction = function (el) {
        var pageNumber = $(el).data("page-number");
        this.setProperty("PageNumber", pageNumber);
        console.log(this.getProperty("PageNumber"));
        currentPagesSet = false;
        totalItemsSet = false;
        thisWidget.jqElement.triggerHandler("GetData");
    };

    this.afterRender = function () {
        pageControlsElement = thisWidget.jqElement.find(".page-controls");
        itemsLabelElement = thisWidget.jqElement.find(".items-label");

        var classList = "";
        classList += thisWidget.getProperty('VerticalAlignment');

        thisWidget.jqElement.addClass(classList);

        thisWidget.jqElement.on('click', '.pagingcontroller', function (e) {
            thisWidget.executePagingAction(this);
        });
    };

    this.renderStyles = function () {
        var styleBlock = '';

        var linkStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('LinkStyle', 'DefaultLinkStyle'));
        var linkHoverStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('HoverStyle', 'DefaultLinkHoverStyle'));
        var currentPageStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('CurrentPageStyle', 'DefaultMashupStyle'));
        var labelStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('LabelStyle', 'DefaultMashupStyle'));

        var linkRule = TW.getStyleCssTextualNoBackgroundFromStyle(linkStyle) +
            TW.getTextSize(linkStyle.textSize);

        var hoverRule =TW.getStyleCssTextualNoBackgroundFromStyle(linkHoverStyle) +
            TW.getTextSize(linkHoverStyle.textSize);

        var currentRule = TW.getStyleCssTextualNoBackgroundFromStyle(currentPageStyle) +
            TW.getTextSize(currentPageStyle.textSize);

        var labelRule = TW.getStyleCssTextualNoBackgroundFromStyle(labelStyle) +
            TW.getTextSize(labelStyle.textSize);

        if (thisWidget.getProperty('LinkStyle', 'DefaultLinkStyle') === 'DefaultLinkStyle'
            && thisWidget.getProperty('HoverStyle', 'DefaultLinkHoverStyle') === 'DefaultLinkHoverStyle'
            && thisWidget.getProperty('CurrentPageStyle', 'DefaultMashupStyle') === 'DefaultMashupStyle') {
            if (!addedDefaultStyles) {
                addedDefaultStyles = true;
                var defaultStyles = ".widget-paging .items-label, " +
                    ".widget-paging .next-ellipsis, " +
                    ".widget-paging .previous-elllipsis { " + labelRule + " } " +
                    ".widget-paging .pagingcontroller { " + linkRule + " } " +
                    ".widget-paging .pagingcontroller:hover { " + hoverRule + " } " +
                    ".widget-paging .current-page { " + currentRule + " }";
                $.rule(defaultStyles).appendTo(TW.Runtime.globalWidgetStyleEl);
            }
        } else {
            styleBlock = "#" + thisWidget.jqElementId + " .items-label," +
                "#" + thisWidget.jqElementId + " .next-ellipsis, .widget-paging .previous-elllipsis { " + labelRule + " } " +
                "#" + thisWidget.jqElementId + " .pagingcontroller { " + linkRule + " } " +
                "#" + thisWidget.jqElementId + " .pagingcontroller:hover { " + hoverRule + "} " +
                "#" + thisWidget.jqElementId + " .current-page { " + currentRule + " }";
        }
        return styleBlock;
    };

    this.updateProperty = function (updatePropertyInfo) {
        if (updatePropertyInfo.TargetProperty === "CurrentPage") {
            this.setProperty(updatePropertyInfo.TargetProperty, updatePropertyInfo.RawSinglePropertyValue);
            currentPage = thisWidget.getProperty("CurrentPage");
        } else if (updatePropertyInfo.TargetProperty === "TotalItems") {
            this.setProperty(updatePropertyInfo.TargetProperty, updatePropertyInfo.RawSinglePropertyValue);
            totalItems = thisWidget.getProperty("TotalItems");
        } else if (updatePropertyInfo.TargetProperty === "ItemsLabel") {
            this.setProperty(updatePropertyInfo.TargetProperty, updatePropertyInfo.SinglePropertyValue);
            itemsLabelElement.text(updatePropertyInfo.SinglePropertyValue);
        }

        if (currentPage >= 0 && totalItems >= 0) {
            TW.emptyJqElement(pageControlsElement);
            pageControlsElement.html(getPageControlsHtml());
        }

    };

    this.beforeDestroy = function () {
        try {
            thisWidget.jqElement.unbind();
        } catch (err) {
            TW.log.error('Error in TW.Runtime.Widgets.paging.beforeDestroy', err);
        }
    };


};
