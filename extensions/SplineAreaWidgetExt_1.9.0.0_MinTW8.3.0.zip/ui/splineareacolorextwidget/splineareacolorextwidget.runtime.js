TW.Runtime.Widgets.splineareacolorextwidget= function () {
	var valueElem, thisWidget, thisWidgetId, thisJqElement;
	this.renderHtml = function () {
		// return any HTML you want rendered for your widget
		// If you want it to change depending on properties that the user
		// has set, you can use this.getProperty(propertyName). In
		// this example, we'll just return static HTML
		return 	'<div id="myChart" class="widget-content widget-splineareacolorextwidget">'
					+ '<canvas></canvas>'
				'</div>';
	};
	
	this.properties.ResponsiveLayout = true;

	this.afterRender = function () {
		// NOTE: this.jqElement is the jquery reference to your html dom element
		// 		 that was returned in renderHtml()

		// get a reference to the value element
		thisWidget = this;
		thisJqElement = thisWidget.jqElement;
		thisWidgetId = thisWidget.jqElementId;
		
		if(this.properties.ResponsiveLayout) {
			var width= this.jqElement.width();
		}
		
		
		//valueElem = this.jqElement.find('.splineareacolorextwidget-property');
		// update that DOM element based on the property value that the user set
		// in the mashup builder
		//valueElem.text(this.getProperty('SplineAreaColorExtWidget Property'));
	};
	
	this.resize = function(width,height) {
	     // invoked when widget is resized
	}

	// this is called on your widget anytime bound data changes
	this.updateProperty = function (updatePropertyInfo) {
		// TargetProperty tells you which of your bound properties changed
		if (updatePropertyInfo.TargetProperty === 'data') {
			//valueElem.text(updatePropertyInfo.SinglePropertyValue);

			data = updatePropertyInfo.RawDataFromInvoke;
			
			$(thisJqElement)[0];
			$(thisJqElement).empty();
			$(thisJqElement)[0].innerHTML = '<canvas></canvas>';			
			var chartObj = $(thisJqElement).find("canvas")[0];
			new Chart(chartObj,data);
			this.setProperty('data', data);
		}
	};
};